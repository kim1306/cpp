#include <iostream>
#include <iomanip>
#include <map>
#include "BST.h"
#include "date.h"
#include "Time.h"
#include "singleWeatherStat.h"
#include "dataProcessor.h"
#include "compute.h"

using namespace std;

// ============================================================================
// DISPLAY FUNCTIONS (Simple - No Callbacks, No Lambdas)
// ============================================================================

void displayAllData(const std::map<int, Bst<singleWeatherStat>>& database)
{
    cout << "\n" << string(60, '-') << endl;
    cout << "ALL LOADED DATA" << endl;
    cout << string(60, '-') << endl;

    if (database.empty()) {
        cout << "No data loaded." << endl;
        return;
    }

    // Simple loop through all years - no callback, no lambda
    for (const auto& yearPair : database) {
        int year = yearPair.first;
        const Bst<singleWeatherStat>& bst = yearPair.second;

        // Get all records for this year
        Vector<singleWeatherStat> records = bst.getAll();

        cout << "\nYear " << year << " (" << records.getSize() << " records):" << endl;

        // Simple loop to display records
        for (int i = 0; i < records.getSize(); i++) {
            cout << "  ";
            records[i].display();
            cout << endl;
        }
    }
}

// ============================================================================
// MENU FUNCTIONS
// ============================================================================

int displayMainMenu()
{
    cout << "\n" << string(60, '=') << endl;
    cout << "WEATHER DATA ANALYSIS SYSTEM" << endl;
    cout << string(60, '=') << endl;
    cout << "\n1. Display all loaded data (by year)" << endl;
    cout << "2. Get average wind speed (month & year)" << endl;
    cout << "3. Get wind speed std deviation (month & year)" << endl;
    cout << "4. Get average temperature (month & year)" << endl;
    cout << "5. Get temperature std deviation (month & year)" << endl;
    cout << "6. Get total solar radiation (month & year)" << endl;
    cout << "7. Get Pearson correlation (month & type)" << endl;
    cout << "8. Exit" << endl;
    cout << "\nEnter choice (1-8): ";

    int choice;
    cin >> choice;
    cin.ignore();
    return choice;
}

int getMonth()
{
    int month;
    cout << "Enter month (1-12): ";
    cin >> month;
    cin.ignore();

    if (month < 1 || month > 12) {
        cout << "Invalid month. Using 1." << endl;
        return 1;
    }
    return month;
}

int getYear()
{
    int year;
    cout << "Enter year (e.g., 2015): ";
    cin >> year;
    cin.ignore();

    if (year < 1900 || year > 2100) {
        cout << "Invalid year. Using 2015." << endl;
        return 2015;
    }
    return year;
}

string getCorrelationType()
{
    string type;
    cout << "Enter type (ST=wind-temp, SR=wind-solar, TR=temp-solar): ";
    getline(cin, type);

    if (type != "ST" && type != "st" &&
        type != "SR" && type != "sr" &&
        type != "TR" && type != "tr") {
        cout << "Invalid type. Using ST." << endl;
        return "ST";
    }
    return type;
}

// ============================================================================
// HANDLER FUNCTIONS
// ============================================================================

void handleDisplayAll(const std::map<int, Bst<singleWeatherStat>>& database)
{
    displayAllData(database);
}

void handleAvgWind(compute& analyzer)
{
    int month = getMonth();
    int year = getYear();

    float avg = analyzer.getAvgWind(month, year);
    cout << fixed << setprecision(2);
    cout << "\nAverage wind speed for month " << month
         << " in year " << year << ": " << avg << " km/h" << endl;
}

void handleStdevWind(compute& analyzer)
{
    int month = getMonth();
    int year = getYear();

    float stdev = analyzer.getStdevWind(month, year);
    cout << fixed << setprecision(2);
    cout << "\nWind speed std deviation for month " << month
         << " in year " << year << ": " << stdev << " km/h" << endl;
}

void handleAvgTemp(compute& analyzer)
{
    int month = getMonth();
    int year = getYear();

    float avg = analyzer.getAvgTemp(month, year);
    cout << fixed << setprecision(2);
    cout << "\nAverage temperature for month " << month
         << " in year " << year << ": " << avg << " °C" << endl;
}

void handleStdevTemp(compute& analyzer)
{
    int month = getMonth();
    int year = getYear();

    float stdev = analyzer.getStdevTemp(month, year);
    cout << fixed << setprecision(2);
    cout << "\nTemperature std deviation for month " << month
         << " in year " << year << ": " << stdev << " °C" << endl;
}

void handleTotalSolar(compute& analyzer)
{
    int month = getMonth();
    int year = getYear();

    float total = analyzer.getTotalSolarRad(month, year);
    cout << fixed << setprecision(2);
    cout << "\nTotal solar radiation for month " << month
         << " in year " << year << ": " << total << " kWh/m²" << endl;
}

void handleCorrelation(compute& analyzer)
{
    int month = getMonth();
    string type = getCorrelationType();

    double correlation = analyzer.getSPCC(month, type);
    cout << fixed << setprecision(4);
    cout << "\nPearson correlation (" << type << ") for month "
         << month << ": " << correlation << endl;
}

// ============================================================================
// MAIN PROGRAM
// ============================================================================

int main()
{
    cout << "\n" << string(60, '=') << endl;
    cout << "WEATHER DATA SYSTEM - INITIALIZATION" << endl;
    cout << string(60, '=') << endl;

    // Load data
    cout << "\nLoading data from CSV files..." << endl;
    dataProcessor loader;

    try {
        loader.openfile("data/data_source.txt");
        cout << "✓ Data loaded successfully!" << endl;
    } catch (const exception& e) {
        cerr << "✗ Error loading data: " << e.what() << endl;
        cerr << "Make sure 'file_list.txt' and CSV files are in the working directory." << endl;
        return 1;
    }

    // Get database reference
    const std::map<int, Bst<singleWeatherStat>>& database = loader.getDatabase();

    // Display summary
    cout << "Data structure: std::map<year, BST<singleWeatherStat>>" << endl;
    cout << "Years loaded: " << database.size() << endl;

    // Create analyzer
    compute analyzer(database);

    // Menu loop
    bool running = true;
    while (running) {
        int choice = displayMainMenu();

        switch (choice) {
            case 1:
                handleDisplayAll(database);
                break;
            case 2:
                handleAvgWind(analyzer);
                break;
            case 3:
                handleStdevWind(analyzer);
                break;
            case 4:
                handleAvgTemp(analyzer);
                break;
            case 5:
                handleStdevTemp(analyzer);
                break;
            case 6:
                handleTotalSolar(analyzer);
                break;
            case 7:
                handleCorrelation(analyzer);
                break;
            case 8:
                running = false;
                cout << "\nExiting... Goodbye!" << endl;
                break;
            default:
                cout << "Invalid choice. Please enter 1-8." << endl;
        }
    }

    cout << string(60, '=') << endl;
    return 0;
}
